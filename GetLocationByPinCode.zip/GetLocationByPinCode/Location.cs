﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GetLocationByPinCode
{
    [Serializable]
    public class Location
    {
        public string Name { get; set; }
        public string District { get; set; }
        public string Division { get; set; }
        public string Region { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
    }
}