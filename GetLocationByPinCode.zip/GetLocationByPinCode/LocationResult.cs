﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GetLocationByPinCode
{
    [Serializable]
    public class LocationResult
    {
        public string Message { get; set; }
        public string Status { get; set; }
        public List<Location> PostOffice { get; set; }
    }
}